from django.apps import AppConfig


class TempAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'temp_app'
