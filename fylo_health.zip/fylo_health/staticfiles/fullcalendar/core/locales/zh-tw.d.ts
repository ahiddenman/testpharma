import { LocaleInput } from '../index.js';

declare const _default: LocaleInput;
//# sourceMappingURL=zh-tw.d.ts.map

export { _default as default };
