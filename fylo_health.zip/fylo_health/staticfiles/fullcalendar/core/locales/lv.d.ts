import { LocaleInput } from '../index.js';

declare const _default: LocaleInput;
//# sourceMappingURL=lv.d.ts.map

export { _default as default };
